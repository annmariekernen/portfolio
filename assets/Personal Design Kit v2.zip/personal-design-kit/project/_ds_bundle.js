/* @ds-bundle: {"format":4,"namespace":"PersonalDesignKit_019deb","components":[{"name":"Button","sourcePath":"components/Button/Button.jsx"},{"name":"Card","sourcePath":"components/Card/Card.jsx"},{"name":"MetaLine","sourcePath":"components/MetaLine/MetaLine.jsx"},{"name":"SectionMarker","sourcePath":"components/SectionMarker/SectionMarker.jsx"},{"name":"Tag","sourcePath":"components/Tag/Tag.jsx"}],"sourceHashes":{"components/Button/Button.jsx":"a36926c8b35e","components/Card/Card.jsx":"68134b18a91e","components/MetaLine/MetaLine.jsx":"03f2eb7b6b78","components/SectionMarker/SectionMarker.jsx":"d9cf2b668fc3","components/Tag/Tag.jsx":"981a2ff9dae4","ui_kits/case_study/header.jsx":"037d457e6864","ui_kits/case_study/sections.jsx":"d1dc779d78f8","ui_kits/portfolio/chrome.jsx":"a356dbb8caf6","ui_kits/portfolio/hero.jsx":"a524ce127aca","ui_kits/portfolio/primitives.jsx":"c6898fcf0f94","ui_kits/portfolio/sections.jsx":"60a3aa7bdea2","ui_kits/portfolio/workgrid.jsx":"1fcf1b7bef96"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PersonalDesignKit_019deb = window.PersonalDesignKit_019deb || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/Button/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  children,
  variant = 'primary',
  onClick,
  as = 'button',
  href,
  disabled = false,
  onInk = false
}) {
  const base = {
    fontFamily: 'var(--font-body)',
    fontVariationSettings: "'wdth' var(--wdth-body)",
    fontWeight: 600,
    fontSize: 'var(--fs-base)',
    fontVariantCaps: 'var(--caps-variant)',
    fontFeatureSettings: 'var(--caps-features)',
    letterSpacing: 'var(--ls-caps)',
    textTransform: 'none',
    padding: '11px 18px',
    border: 'var(--border-default)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    display: 'inline-block',
    textDecoration: 'none',
    transition: 'background var(--dur-fast) var(--ease-snap), border-color var(--dur-fast) var(--ease-snap)'
  };
  const variants = {
    primary: {
      background: 'var(--action)',
      borderColor: 'var(--action)',
      color: 'var(--action-fg)'
    },
    secondary: {
      background: 'var(--green-deep)',
      borderColor: 'var(--green-deep)',
      color: 'var(--bone)'
    },
    ghost: {
      background: 'transparent',
      borderColor: onInk ? 'var(--mist)' : 'var(--ink)',
      color: onInk ? 'var(--paper)' : 'var(--fg-1)'
    },
    ink: {
      background: 'var(--ink)',
      borderColor: 'var(--ink)',
      color: 'var(--paper)'
    }
  };
  const hovers = {
    primary: {
      background: 'var(--action-hover)',
      borderColor: 'var(--action-hover)'
    },
    secondary: {
      background: 'var(--green-deeper)',
      borderColor: 'var(--green-deeper)'
    },
    ghost: onInk ? {
      background: 'var(--ink-soft)',
      borderColor: 'var(--paper)'
    } : {
      background: 'var(--mist-pale)'
    },
    ink: {
      background: 'var(--ink-soft)',
      borderColor: 'var(--ink-soft)'
    }
  };
  const off = {
    background: 'var(--mist-pale)',
    borderColor: 'var(--mist)',
    color: 'var(--ink-faint)'
  };
  const [hover, setHover] = React.useState(false);
  const v = variants[variant] || variants.primary;
  const buttonStyle = {
    ...base,
    ...v,
    ...(hover && !disabled ? hovers[variant] : null),
    ...(disabled ? off : null)
  };
  const handlers = disabled ? {} : {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick
  };
  return as === 'a' ? /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: buttonStyle
  }, handlers), children) : /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: buttonStyle
  }, handlers), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Button/Button.jsx", error: String((e && e.message) || e) }); }

// components/Card/Card.jsx
try { (() => {
const SURFACES = {
  bone: 'var(--bone)',
  paper: 'var(--paper)',
  quiet: 'var(--paper-2)',
  bluePale: 'var(--blue-pale)',
  greenPale: 'var(--green-pale)',
  ink: 'var(--ink)'
};

/** Ghost outline variants must match the surface BEHIND the card. */
const GHOSTS = {
  paper: 'var(--ghost)',
  alt: 'var(--ghost-alt)',
  bright: 'var(--ghost-bright)',
  none: 'none'
};
function Card({
  children,
  fill = 'bone',
  ghost = 'paper',
  hero = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: SURFACES[fill] || SURFACES.bone,
      border: hero ? 'var(--border-heavy)' : 'var(--border-default)',
      boxShadow: GHOSTS[ghost] || GHOSTS.paper,
      padding: hero ? 'var(--space-7)' : 'var(--space-6)',
      color: fill === 'ink' ? 'var(--fg-inverse)' : 'var(--fg-1)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Card/Card.jsx", error: String((e && e.message) || e) }); }

// components/MetaLine/MetaLine.jsx
try { (() => {
function MetaLine({
  children,
  tone = 'muted'
}) {
  const tones = {
    muted: 'var(--fg-3)',
    ink: 'var(--fg-1)',
    inverse: 'var(--mist)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontSize: 'var(--fs-sm)',
      fontWeight: 500,
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      color: tones[tone] || tones.muted
    }
  }, children);
}
Object.assign(__ds_scope, { MetaLine });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/MetaLine/MetaLine.jsx", error: String((e && e.message) || e) }); }

// components/SectionMarker/SectionMarker.jsx
try { (() => {
function SectionMarker({
  num,
  children,
  rule = 'default'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-5)',
      padding: '0 0 14px 0',
      borderBottom: rule === 'heavy' ? 'var(--border-heavy)' : 'var(--border-default)',
      marginBottom: 'var(--space-7)',
      flexWrap: 'wrap'
    }
  }, num && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontWeight: 700,
      fontSize: 'var(--fs-base)',
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      color: 'var(--fg-3)',
      flexShrink: 0
    }
  }, num), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'var(--fs-2xl)',
      lineHeight: 'var(--lh-tight)',
      letterSpacing: 'var(--ls-tight)'
    }
  }, children));
}
Object.assign(__ds_scope, { SectionMarker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/SectionMarker/SectionMarker.jsx", error: String((e && e.message) || e) }); }

// components/Tag/Tag.jsx
try { (() => {
const FILLS = {
  default: {
    background: 'transparent',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  blue: {
    background: 'var(--blue-deep)',
    color: 'var(--bone)',
    borderColor: 'var(--blue-deep)'
  },
  green: {
    background: 'var(--green-deep)',
    color: 'var(--bone)',
    borderColor: 'var(--green-deep)'
  },
  bluePale: {
    background: 'var(--blue-pale)',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  greenPale: {
    background: 'var(--green-pale)',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  mist: {
    background: 'var(--mist-pale)',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  rust: {
    background: 'var(--rust)',
    color: 'var(--bone)',
    borderColor: 'var(--rust)'
  },
  ink: {
    background: 'var(--ink)',
    color: 'var(--paper)',
    borderColor: 'var(--ink)'
  }
};
function Tag({
  children,
  variant = 'default',
  dot = false
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontSize: 'var(--fs-sm)',
      fontWeight: 600,
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      padding: '4px 10px',
      border: 'var(--border-default)',
      ...(FILLS[variant] || FILLS.default)
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      background: 'currentColor',
      display: 'inline-block'
    }
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Tag/Tag.jsx", error: String((e && e.message) || e) }); }

// ui_kits/case_study/header.jsx
try { (() => {
window.CaseHeader = function CaseHeader() {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      borderBottom: 'var(--border-heavy)',
      background: 'var(--paper)',
      padding: '16px 40px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "../portfolio/index.html",
    style: {
      textDecoration: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 18,
      letterSpacing: '-0.01em',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, "\u25C2 STUDIO", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--blue-deep)'
    }
  }, "//")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--fg-3)',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      background: 'var(--green-deep)',
      display: 'inline-block'
    }
  }), "\u25B8 reading \xB7 case 03 / 12"));
};
window.CaseHero = function CaseHero({
  tag,
  title,
  sub,
  year,
  role,
  team,
  duration
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '72px 48px 56px',
      borderBottom: 'var(--border-default)',
      background: 'var(--paper)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    variant: "blue"
  }, tag), /*#__PURE__*/React.createElement(Tag, null, "\u25B8 ", year)), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'clamp(44px, 5.8vw, 72px)',
      lineHeight: 1.02,
      letterSpacing: '-0.03em',
      maxWidth: '18ch'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 26,
      fontSize: 20,
      lineHeight: 1.45,
      color: 'var(--fg-2)',
      maxWidth: '56ch'
    }
  }, sub), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 44,
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      border: 'var(--border-default)',
      background: 'var(--bone)'
    }
  }, /*#__PURE__*/React.createElement(CaseFact, {
    label: "Role",
    value: role
  }), /*#__PURE__*/React.createElement(CaseFact, {
    label: "Team",
    value: team
  }), /*#__PURE__*/React.createElement(CaseFact, {
    label: "Duration",
    value: duration,
    last: true
  }))));
};
function CaseFact({
  label,
  value,
  last
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 22px',
      borderRight: last ? 'none' : 'var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--fg-3)'
    }
  }, "// ", label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 600,
      marginTop: 6,
      lineHeight: 1.25
    }
  }, value));
}
window.MetricRow = function MetricRow({
  items
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '44px 48px',
      borderBottom: 'var(--border-default)',
      background: 'var(--ink)',
      color: 'var(--fg-inverse)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: `repeat(${items.length}, 1fr)`
    }
  }, items.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: '6px 24px',
      borderRight: i < items.length - 1 ? '1px solid var(--ink-soft)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--mist)'
    }
  }, "// ", m.label), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 44,
      lineHeight: 1,
      letterSpacing: '-0.03em',
      color: m.color || 'var(--paper)'
    }
  }, m.value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      fontSize: 12,
      color: 'var(--ink-faint)'
    }
  }, m.note)))));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/case_study/header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/case_study/sections.jsx
try { (() => {
window.Prose = function Prose({
  children,
  kicker,
  heading
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 48px',
      background: 'var(--paper)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '68ch',
      margin: '0 auto'
    }
  }, kicker && /*#__PURE__*/React.createElement(SectionMarker, {
    num: kicker
  }, heading), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      lineHeight: 1.6,
      color: 'var(--fg-1)'
    }
  }, children)));
};
window.QuoteBlock = function QuoteBlock({
  children,
  attrib
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '56px 48px',
      background: 'var(--blue-pale)',
      borderTop: 'var(--border-default)',
      borderBottom: 'var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '40px 1fr',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 76,
      lineHeight: 0.78,
      color: 'var(--blue-deep)'
    }
  }, "\""), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'clamp(26px, 3.4vw, 38px)',
      lineHeight: 1.12,
      letterSpacing: 'var(--ls-tight)'
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18,
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--fg-2)'
    }
  }, "\u25B8 ", attrib))));
};
window.BeforeAfter = function BeforeAfter() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 48px',
      background: 'var(--paper-2)',
      borderBottom: 'var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(SectionMarker, {
    num: "[03]"
  }, "Before \u2192 after"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 56px 1fr',
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement(Frame, {
    label: "Before \xB7 2024.Q1",
    tone: "bad"
  }, /*#__PURE__*/React.createElement(FakeUI, {
    variant: "before"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 40,
      color: 'var(--ink-faint)',
      lineHeight: 1
    }
  }, "\u2192")), /*#__PURE__*/React.createElement(Frame, {
    label: "After \xB7 2025.Q2",
    tone: "good"
  }, /*#__PURE__*/React.createElement(FakeUI, {
    variant: "after"
  })))));
};
function Frame({
  children,
  label,
  tone
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 700,
      background: tone === 'good' ? 'var(--green-deep)' : 'var(--rust)',
      color: 'var(--bone)',
      padding: '6px 10px',
      display: 'inline-block'
    }
  }, "// ", label), /*#__PURE__*/React.createElement("div", {
    style: {
      border: 'var(--border-default)',
      background: 'var(--bone)',
      padding: 16,
      minHeight: 340
    }
  }, children));
}
function FakeUI({
  variant
}) {
  if (variant === 'before') {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--fg-2)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        borderBottom: '1px solid var(--rule)',
        paddingBottom: 8,
        marginBottom: 12
      }
    }, "file \xB7 edit \xB7 view \xB7 admin \xB7 system \xB7 billing \xB7 users \xB7 reports \xB7 settings \xB7 help"), Array.from({
      length: 9
    }).map((_, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        padding: '6px 0',
        borderBottom: '1px solid var(--rule)'
      }
    }, /*#__PURE__*/React.createElement("span", null, "row_", String(i + 1).padStart(3, '0'), " \xB7 long.descriptive.name"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--rust)'
      }
    }, "3 dropdowns \u25BE"))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 14,
        color: 'var(--rust)'
      }
    }, "// 12 dashboards. nobody knows where anything is \u2014 bless their hearts."));
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--ink)',
      color: 'var(--paper)',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      padding: '10px 12px',
      marginBottom: 14
    }
  }, "\u2318K \xA0> find anything_"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, ['create user', 'export billing.csv', 'view incident #4823', 'open dashboard ▸ throughput', 'run reconciliation'].map((cmd, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: '10px 12px',
      background: i === 0 ? 'var(--blue-pale)' : 'var(--bone)',
      border: 'var(--border-default)',
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, cmd), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fg-3)'
    }
  }, "\u21B5")))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--fg-3)'
    }
  }, "// one palette. everything reachable in <2 keystrokes. lovely!"));
}
window.ProcessTimeline = function ProcessTimeline() {
  const steps = [{
    n: '01',
    label: 'Audit',
    body: 'shadowed 6 ops people for a week. counted clicks. it was bad.'
  }, {
    n: '02',
    label: 'Map',
    body: 'every screen, every state, on one wall. printed and pinned.'
  }, {
    n: '03',
    label: 'Prototype',
    body: 'three directions. fastest one was a glorified terminal. obviously.'
  }, {
    n: '04',
    label: 'Test',
    body: 'live ops + new hires. measured time-to-task before & after.'
  }, {
    n: '05',
    label: 'Ship',
    body: 'rolled out behind a flag. opt-in to opt-out in 11 days.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '64px 48px',
      background: 'var(--paper)',
      borderBottom: 'var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(SectionMarker, {
    num: "[04]"
  }, "Process"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: 'var(--border-default)',
      background: 'var(--bone)',
      display: 'grid',
      gridTemplateColumns: `repeat(${steps.length}, 1fr)`
    }
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: {
      padding: '22px 18px',
      minHeight: 196,
      borderRight: i < steps.length - 1 ? 'var(--border-default)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--fg-3)',
      marginBottom: 14
    }
  }, "[", s.n, "]"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 19,
      letterSpacing: 'var(--ls-tight)',
      marginBottom: 8
    }
  }, s.label), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, s.body))))));
};
window.NextCase = function NextCase() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '52px 48px',
      background: 'var(--paper-2)',
      borderBottom: 'var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: '0 auto',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 32,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--fg-3)'
    }
  }, "// up next, if you'd like"), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '10px 0 0',
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'clamp(30px, 3.8vw, 48px)',
      lineHeight: 1.04,
      letterSpacing: '-0.03em'
    }
  }, "Notes app, again \u2192")), /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#next"
  }, "Read next \u25B8")));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/case_study/sections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/chrome.jsx
try { (() => {
window.TopNav = function TopNav({
  active = 'work',
  onNav
}) {
  const items = [{
    id: 'work',
    label: 'Work'
  }, {
    id: 'notes',
    label: 'Field notes'
  }, {
    id: 'now',
    label: 'Now'
  }, {
    id: 'about',
    label: 'About'
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      borderBottom: 'var(--border-heavy)',
      background: 'var(--paper)',
      position: 'sticky',
      top: 0,
      zIndex: 10,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 40px',
      height: 66
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#home",
    onClick: e => {
      e.preventDefault();
      onNav && onNav('home');
    },
    style: {
      textDecoration: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.01em'
    }
  }, "STUDIO", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--blue-deep)'
    }
  }, "//")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 28
    }
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.id,
    href: '#' + it.id,
    onClick: e => {
      e.preventDefault();
      onNav && onNav(it.id);
    },
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 15,
      fontWeight: 600,
      textDecoration: 'none',
      color: active === it.id ? 'var(--fg-1)' : 'var(--fg-2)',
      borderBottom: active === it.id ? 'var(--border-default)' : '1.5px solid transparent',
      paddingBottom: 3
    }
  }, it.label)), /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#contact"
  }, "Hire me \u25B8")));
};
window.Footer = function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: 'var(--border-heavy)',
      background: 'var(--ink)',
      color: 'var(--fg-inverse)',
      padding: '56px 48px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 30,
      letterSpacing: '-0.02em'
    }
  }, "STUDIO", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--mist)'
    }
  }, "//")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.55,
      marginTop: 14,
      maxWidth: 360,
      color: 'var(--mist)'
    }
  }, "ux designer. systems person. shipping things since the dial-up era.")), /*#__PURE__*/React.createElement(FootCol, {
    title: "Work",
    items: ['Case studies', 'Now', 'Archive']
  }), /*#__PURE__*/React.createElement(FootCol, {
    title: "Writing",
    items: ['Field notes', 'Talks', 'Receipts']
  }), /*#__PURE__*/React.createElement(FootCol, {
    title: "Elsewhere",
    items: ['Email ↗', 'GitHub ↗', 'read.cv ↗']
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1 / -1',
      borderTop: '1px solid var(--ink-soft)',
      paddingTop: 22,
      marginTop: 12,
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 12,
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--ink-faint)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "// \xA9 2026 \xB7 made with care"), /*#__PURE__*/React.createElement("span", null, "v0.2 \xB7 last deploy 2h ago, thanks for visiting"))));
};
function FootCol({
  title,
  items
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--mist)',
      marginBottom: 14
    }
  }, "// ", title), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      padding: 0,
      margin: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 9
    }
  }, items.map(i => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#link",
    onClick: e => e.preventDefault(),
    style: {
      color: 'var(--paper)',
      textDecoration: 'none'
    }
  }, i)))));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/hero.jsx
try { (() => {
window.Hero = function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      borderBottom: 'var(--border-default)',
      padding: '88px 48px 72px',
      background: 'var(--paper)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      background: 'var(--green-deep)',
      display: 'inline-block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 15,
      fontWeight: 600,
      color: 'var(--fg-2)'
    }
  }, "// hi! taking new work for q3 \xB7 sf / remote")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'clamp(44px, 5.6vw, 72px)',
      lineHeight: 1.02,
      letterSpacing: '-0.03em',
      maxWidth: '17ch'
    }
  }, "Complex systems, warmly shipped."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 32,
      maxWidth: '52ch',
      fontSize: 19,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, "hi, i'm a ux designer for complex products \u2014 admin tools, design tooling, anything with a sidebar and a real workflow. pull up a chair, the kettle's on. i'd love to show you what i've been building."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginTop: 36,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#work"
  }, "Come see the work \u25B8"), /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#contact",
    variant: "ghost"
  }, "Say hello \u25B8"))));
};
window.MarqueeStrip = function MarqueeStrip() {
  const items = ['Design systems', 'Prototypes', 'Research ops', 'Zero→one', '▸', 'Enterprise tools', 'Motion', 'Workflow design', '▸', 'API design', 'Design eng', '▸'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--paper-2)',
      color: 'var(--fg-2)',
      borderBottom: 'var(--border-default)',
      padding: '13px 0',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontWeight: 600,
      fontSize: 15,
      letterSpacing: '0.12em'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-block',
      animation: 'scroll 60s linear infinite'
    }
  }, [...items, ...items, ...items].map((it, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      padding: '0 22px'
    }
  }, it))), /*#__PURE__*/React.createElement("style", null, `@keyframes scroll { 0% { transform: translateX(0) } 100% { transform: translateX(-33.333%) } }`));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/primitives.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Local mirrors of the library primitives, styled entirely from tokens.
   Cherry-pick these into prototypes, or import the compiled components. */

const BTN_BASE = {
  fontFamily: 'var(--font-body)',
  fontVariationSettings: "'wdth' var(--wdth-body)",
  fontVariantCaps: 'var(--caps-variant)',
  fontFeatureSettings: 'var(--caps-features)',
  letterSpacing: 'var(--ls-caps)',
  textTransform: 'none',
  fontWeight: 600,
  fontSize: 'var(--fs-base)',
  padding: '11px 18px',
  border: 'var(--border-default)',
  cursor: 'pointer',
  display: 'inline-block',
  textDecoration: 'none',
  transition: 'background var(--dur-fast) var(--ease-snap), border-color var(--dur-fast) var(--ease-snap)'
};
window.Button = function Button({
  children,
  variant = 'primary',
  onClick,
  as = 'button',
  href,
  disabled = false,
  onInk = false
}) {
  const rest = {
    primary: {
      background: 'var(--action)',
      borderColor: 'var(--action)',
      color: 'var(--action-fg)'
    },
    secondary: {
      background: 'var(--green-deep)',
      borderColor: 'var(--green-deep)',
      color: 'var(--bone)'
    },
    ghost: {
      background: 'transparent',
      borderColor: onInk ? 'var(--mist)' : 'var(--ink)',
      color: onInk ? 'var(--paper)' : 'var(--fg-1)'
    },
    ink: {
      background: 'var(--ink)',
      borderColor: 'var(--ink)',
      color: 'var(--paper)'
    }
  };
  const over = {
    primary: {
      background: 'var(--action-hover)',
      borderColor: 'var(--action-hover)'
    },
    secondary: {
      background: 'var(--green-deeper)',
      borderColor: 'var(--green-deeper)'
    },
    ghost: onInk ? {
      background: 'var(--ink-soft)',
      borderColor: 'var(--paper)'
    } : {
      background: 'var(--mist-pale)'
    },
    ink: {
      background: 'var(--ink-soft)',
      borderColor: 'var(--ink-soft)'
    }
  };
  const [hover, setHover] = React.useState(false);
  const style = {
    ...BTN_BASE,
    ...(rest[variant] || rest.primary),
    ...(hover && !disabled ? over[variant] : null),
    ...(disabled ? {
      background: 'var(--mist-pale)',
      borderColor: 'var(--mist)',
      color: 'var(--ink-faint)',
      cursor: 'not-allowed'
    } : null)
  };
  const p = disabled ? {
    style
  } : {
    style,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick
  };
  return as === 'a' ? /*#__PURE__*/React.createElement("a", _extends({
    href: href
  }, p), children) : /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled
  }, p), children);
};
const TAG_FILLS = {
  default: {
    background: 'transparent',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  blue: {
    background: 'var(--blue-deep)',
    color: 'var(--bone)',
    borderColor: 'var(--blue-deep)'
  },
  green: {
    background: 'var(--green-deep)',
    color: 'var(--bone)',
    borderColor: 'var(--green-deep)'
  },
  bluePale: {
    background: 'var(--blue-pale)',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  greenPale: {
    background: 'var(--green-pale)',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  mist: {
    background: 'var(--mist-pale)',
    color: 'var(--fg-1)',
    borderColor: 'var(--ink)'
  },
  rust: {
    background: 'var(--rust)',
    color: 'var(--bone)',
    borderColor: 'var(--rust)'
  },
  ink: {
    background: 'var(--ink)',
    color: 'var(--paper)',
    borderColor: 'var(--ink)'
  }
};
window.Tag = function Tag({
  children,
  variant = 'default',
  dot = false
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 'var(--fs-sm)',
      fontWeight: 600,
      padding: '4px 10px',
      border: 'var(--border-default)',
      ...(TAG_FILLS[variant] || TAG_FILLS.default)
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      background: 'currentColor',
      display: 'inline-block'
    }
  }), children);
};
const CARD_SURFACES = {
  bone: 'var(--bone)',
  paper: 'var(--paper)',
  quiet: 'var(--paper-2)',
  bluePale: 'var(--blue-pale)',
  greenPale: 'var(--green-pale)',
  ink: 'var(--ink)'
};
const CARD_GHOSTS = {
  paper: 'var(--ghost)',
  alt: 'var(--ghost-alt)',
  bright: 'var(--ghost-bright)',
  none: 'none'
};
window.Card = function Card({
  children,
  fill = 'bone',
  ghost = 'paper',
  hero = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: CARD_SURFACES[fill] || CARD_SURFACES.bone,
      border: hero ? 'var(--border-heavy)' : 'var(--border-default)',
      boxShadow: CARD_GHOSTS[ghost] || CARD_GHOSTS.paper,
      padding: hero ? 'var(--space-7)' : 'var(--space-6)',
      color: fill === 'ink' ? 'var(--fg-inverse)' : 'var(--fg-1)',
      ...style
    }
  }, children);
};
window.MetaLine = function MetaLine({
  children,
  tone = 'muted'
}) {
  const tones = {
    muted: 'var(--fg-3)',
    ink: 'var(--fg-1)',
    inverse: 'var(--mist)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 'var(--fs-sm)',
      fontWeight: 500,
      color: tones[tone] || tones.muted
    }
  }, children);
};
window.SectionMarker = function SectionMarker({
  num,
  children,
  rule = 'default'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-5)',
      padding: '0 0 14px 0',
      borderBottom: rule === 'heavy' ? 'var(--border-heavy)' : 'var(--border-default)',
      marginBottom: 'var(--space-7)',
      flexWrap: 'wrap'
    }
  }, num && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontWeight: 700,
      fontSize: 'var(--fs-base)',
      color: 'var(--fg-3)',
      flexShrink: 0
    }
  }, num), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'var(--fs-2xl)',
      lineHeight: 'var(--lh-tight)',
      letterSpacing: 'var(--ls-tight)'
    }
  }, children));
};

/* Shared section shell: max width, generous vertical rhythm, hairline base. */
window.Band = function Band({
  children,
  alt = false,
  ink = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '72px 48px',
      borderBottom: 'var(--border-default)',
      background: ink ? 'var(--ink)' : alt ? 'var(--paper-2)' : 'var(--paper)',
      color: ink ? 'var(--fg-inverse)' : 'var(--fg-1)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto'
    }
  }, children));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/primitives.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/sections.jsx
try { (() => {
window.NowPlaying = function NowPlaying() {
  return /*#__PURE__*/React.createElement(Band, {
    ink: true,
    style: {
      borderBottom: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 2fr',
      gap: 48,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 34,
      lineHeight: 1.05,
      letterSpacing: 'var(--ls-tight)'
    }
  }, "Now playing"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--ink-faint)'
    }
  }, "// last updated 2026.08.27")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(NowRow, {
    status: "Shipping",
    color: "var(--green)",
    label: "Notes app, v0.3",
    desc: "finally fixing the graph layer i broke in v0.2 \u2014 close!"
  }), /*#__PURE__*/React.createElement(NowRow, {
    status: "Reading",
    color: "var(--mist)",
    label: "every public design system",
    desc: "yes, all of them. happy to swap notes over coffee."
  }), /*#__PURE__*/React.createElement(NowRow, {
    status: "Writing",
    color: "var(--blue)",
    label: "design tokens that don't lie",
    desc: "a friendly conf talk. 22 min. receipts inside."
  }), /*#__PURE__*/React.createElement(NowRow, {
    status: "Open",
    color: "var(--green)",
    label: "freelance, q3",
    desc: "2 slots open. drop me a line, i'd love to hear about it."
  }))));
};
function NowRow({
  status,
  color,
  label,
  desc
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '116px 1fr',
      gap: 24,
      alignItems: 'baseline',
      paddingBottom: 14,
      borderBottom: '1px solid var(--ink-soft)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      background: color,
      display: 'inline-block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 14,
      fontWeight: 700,
      color
    }
  }, status)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 19,
      fontWeight: 600,
      lineHeight: 1.25
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--mist)',
      marginTop: 5
    }
  }, desc)));
}
window.PrincipleStrip = function PrincipleStrip() {
  const principles = [{
    n: '01',
    title: 'Specifics > vibes',
    body: 'numbers, screenshots, the exact words. happy to show the receipts.'
  }, {
    n: '02',
    title: 'Constraint as gift',
    body: 'every "we can\'t" is a little design brief, generously wrapped.'
  }, {
    n: '03',
    title: 'Boring on purpose',
    body: "novel UI is a tax. let's spend it where it earns its keep."
  }, {
    n: '04',
    title: 'Ship to learn',
    body: 'a v0.1 in prod beats a v3 in figma. always.'
  }];
  return /*#__PURE__*/React.createElement(Band, {
    alt: true
  }, /*#__PURE__*/React.createElement(SectionMarker, {
    num: "[02]"
  }, "Operating principles"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      border: 'var(--border-default)',
      background: 'var(--bone)'
    }
  }, principles.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p.n,
    style: {
      padding: '24px 22px',
      minHeight: 206,
      borderRight: i < principles.length - 1 ? 'var(--border-default)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--fg-3)'
    }
  }, "[", p.n, "]"), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: '14px 0 10px',
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 21,
      lineHeight: 1.12,
      letterSpacing: 'var(--ls-tight)'
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, p.body)))));
};
window.ContactCTA = function ContactCTA() {
  return /*#__PURE__*/React.createElement(Band, null, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '46ch'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontSize: 15,
      fontWeight: 700,
      color: 'var(--fg-3)',
      marginBottom: 20
    }
  }, "// let's build something lovely together"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 'clamp(36px, 4.4vw, 56px)',
      lineHeight: 1.04,
      letterSpacing: '-0.03em'
    }
  }, "Got a complex problem? I'd love to hear it."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 22,
      fontSize: 18,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, "send it over \u2014 the messier the better. i'll tell you honestly whether i'm the right person for it."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#hello"
  }, "Say hello \u25B8"), /*#__PURE__*/React.createElement(Button, {
    as: "a",
    href: "#chat",
    variant: "ghost"
  }, "Book a 15-min chat \u25B8"))));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/sections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/workgrid.jsx
try { (() => {
window.WorkGrid = function WorkGrid({
  onOpen
}) {
  const items = [{
    id: 'checkout',
    idx: '01',
    year: '2025',
    tag: 'Case study',
    title: 'Rebuilt the checkout',
    sub: 'cut signup 47s → 12s, 38% lift. come see how!',
    fill: 'bone',
    accent: 'var(--blue-deep)'
  }, {
    id: 'notes',
    idx: '02',
    year: '2026',
    tag: 'In progress',
    title: 'Notes app, again',
    sub: 'rewiring the graph layer. v0.3, getting close!',
    fill: 'quiet',
    accent: 'var(--green-deep)'
  }, {
    id: 'admin',
    idx: '03',
    year: '2024',
    tag: 'Case study',
    title: 'Admin, reimagined',
    sub: '12 dashboards → 1 lovely command palette.',
    fill: 'bone',
    accent: 'var(--blue-deep)'
  }, {
    id: 'tokens',
    idx: '04',
    year: '2024',
    tag: 'Talk',
    title: "Design tokens that don't lie",
    sub: 'a friendly conf talk. 22 min, receipts inside.',
    fill: 'quiet',
    accent: 'var(--green-deep)'
  }];
  return /*#__PURE__*/React.createElement(Band, null, /*#__PURE__*/React.createElement(SectionMarker, {
    num: "[01]"
  }, "Selected work"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 32
    }
  }, items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it.id,
    href: '#' + it.id,
    onClick: e => {
      e.preventDefault();
      onOpen && onOpen(it.id);
    },
    style: {
      textDecoration: 'none',
      color: 'inherit'
    }
  }, /*#__PURE__*/React.createElement(WorkCard, it)))));
};
function WorkCard({
  idx,
  year,
  tag,
  title,
  sub,
  fill,
  accent
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: fill === 'quiet' ? 'var(--paper-2)' : 'var(--bone)',
      border: 'var(--border-default)',
      boxShadow: hover ? 'var(--ghost)' : 'none',
      transition: 'box-shadow var(--dur-fast) var(--ease-snap)',
      display: 'grid',
      gridTemplateColumns: '1fr 92px',
      minHeight: 212,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 26px',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(MetaLine, null, "\u25B8 ", year, " \xB7 ", tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '10px 0 12px',
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 28,
      lineHeight: 1.08,
      letterSpacing: 'var(--ls-tight)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, sub), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 18,
      fontFamily: 'var(--font-body)',
      fontVariationSettings: "'wdth' var(--wdth-body)",
      fontVariantCaps: 'var(--caps-variant)',
      fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)',
      textTransform: 'none',
      fontWeight: 600,
      fontSize: 16,
      color: accent
    }
  }, "Read it ", hover ? '▸▸' : '▸')), /*#__PURE__*/React.createElement("div", {
    style: {
      borderLeft: 'var(--border-default)',
      background: fill === 'quiet' ? 'var(--bone)' : 'var(--paper-2)',
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'center',
      padding: '20px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontVariationSettings: "'wdth' var(--wdth-display)",
      fontWeight: 700,
      fontSize: 34,
      letterSpacing: '-0.02em',
      color: 'var(--ink-faint)'
    }
  }, idx)));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/workgrid.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MetaLine = __ds_scope.MetaLine;

__ds_ns.SectionMarker = __ds_scope.SectionMarker;

__ds_ns.Tag = __ds_scope.Tag;

})();
