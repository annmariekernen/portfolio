window.Prose = function Prose({ children, kicker, heading }) {
  return (
    <section style={{padding:'64px 48px', background:'var(--paper)'}}>
      <div style={{maxWidth:'68ch', margin:'0 auto'}}>
        {kicker && <SectionMarker num={kicker}>{heading}</SectionMarker>}
        <div style={{fontSize:17, lineHeight:1.6, color:'var(--fg-1)'}}>{children}</div>
      </div>
    </section>
  );
};

window.QuoteBlock = function QuoteBlock({ children, attrib }) {
  return (
    <section style={{
      padding:'56px 48px', background:'var(--blue-pale)',
      borderTop:'var(--border-default)', borderBottom:'var(--border-default)',
    }}>
      <div style={{maxWidth:1000, margin:'0 auto', display:'grid', gridTemplateColumns:'40px 1fr', gap:20, alignItems:'start'}}>
        <div style={{
          fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
          fontWeight:700, fontSize:76, lineHeight:0.78, color:'var(--blue-deep)',
        }}>"</div>
        <div>
          <div style={{
            fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
            fontWeight:700, fontSize:'clamp(26px, 3.4vw, 38px)', lineHeight:1.12, letterSpacing:'var(--ls-tight)',
          }}>{children}</div>
          <div style={{
            marginTop:18, fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:700, color:'var(--fg-2)',
          }}>▸ {attrib}</div>
        </div>
      </div>
    </section>
  );
};

window.BeforeAfter = function BeforeAfter() {
  return (
    <section style={{padding:'64px 48px', background:'var(--paper-2)', borderBottom:'var(--border-default)'}}>
      <div style={{maxWidth:1100, margin:'0 auto'}}>
        <SectionMarker num="[03]">Before → after</SectionMarker>
        <div style={{display:'grid', gridTemplateColumns:'1fr 56px 1fr', alignItems:'stretch'}}>
          <Frame label="Before · 2024.Q1" tone="bad"><FakeUI variant="before"/></Frame>
          <div style={{display:'flex', alignItems:'center', justifyContent:'center'}}>
            <div style={{
              fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
              fontWeight:700, fontSize:40, color:'var(--ink-faint)', lineHeight:1,
            }}>→</div>
          </div>
          <Frame label="After · 2025.Q2" tone="good"><FakeUI variant="after"/></Frame>
        </div>
      </div>
    </section>
  );
};

function Frame({ children, label, tone }) {
  return (
    <div>
      <div style={{
        fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:700,
        background: tone === 'good' ? 'var(--green-deep)' : 'var(--rust)',
        color:'var(--bone)', padding:'6px 10px', display:'inline-block',
      }}>// {label}</div>
      <div style={{border:'var(--border-default)', background:'var(--bone)', padding:16, minHeight:340}}>{children}</div>
    </div>
  );
}

function FakeUI({ variant }) {
  if (variant === 'before') {
    return (
      <div style={{fontFamily:'var(--font-mono)', fontSize:11, color:'var(--fg-2)'}}>
        <div style={{borderBottom:'1px solid var(--rule)', paddingBottom:8, marginBottom:12}}>file · edit · view · admin · system · billing · users · reports · settings · help</div>
        {Array.from({length:9}).map((_, i) => (
          <div key={i} style={{display:'flex', justifyContent:'space-between', padding:'6px 0', borderBottom:'1px solid var(--rule)'}}>
            <span>row_{String(i+1).padStart(3,'0')} · long.descriptive.name</span>
            <span style={{color:'var(--rust)'}}>3 dropdowns ▾</span>
          </div>
        ))}
        <div style={{marginTop:14, color:'var(--rust)'}}>// 12 dashboards. nobody knows where anything is — bless their hearts.</div>
      </div>
    );
  }
  return (
    <div>
      <div style={{
        background:'var(--ink)', color:'var(--paper)', fontFamily:'var(--font-mono)',
        fontSize:13, padding:'10px 12px', marginBottom:14,
      }}>⌘K &nbsp;&gt; find anything_</div>
      <div style={{display:'flex', flexDirection:'column', gap:6}}>
        {['create user','export billing.csv','view incident #4823','open dashboard ▸ throughput','run reconciliation'].map((cmd, i) => (
          <div key={i} style={{
            padding:'10px 12px',
            background: i === 0 ? 'var(--blue-pale)' : 'var(--bone)',
            border:'var(--border-default)',
            fontFamily:'var(--font-mono)', fontSize:12,
            display:'flex', justifyContent:'space-between',
          }}>
            <span>{cmd}</span>
            <span style={{color:'var(--fg-3)'}}>↵</span>
          </div>
        ))}
      </div>
      <div style={{marginTop:14, fontFamily:'var(--font-mono)', fontSize:11, color:'var(--fg-3)'}}>
        // one palette. everything reachable in &lt;2 keystrokes. lovely!
      </div>
    </div>
  );
}

window.ProcessTimeline = function ProcessTimeline() {
  const steps = [
    { n:'01', label:'Audit', body:'shadowed 6 ops people for a week. counted clicks. it was bad.' },
    { n:'02', label:'Map', body:'every screen, every state, on one wall. printed and pinned.' },
    { n:'03', label:'Prototype', body:'three directions. fastest one was a glorified terminal. obviously.' },
    { n:'04', label:'Test', body:'live ops + new hires. measured time-to-task before & after.' },
    { n:'05', label:'Ship', body:'rolled out behind a flag. opt-in to opt-out in 11 days.' },
  ];
  return (
    <section style={{padding:'64px 48px', background:'var(--paper)', borderBottom:'var(--border-default)'}}>
      <div style={{maxWidth:1100, margin:'0 auto'}}>
        <SectionMarker num="[04]">Process</SectionMarker>
        <div style={{
          border:'var(--border-default)', background:'var(--bone)',
          display:'grid', gridTemplateColumns:`repeat(${steps.length}, 1fr)`,
        }}>
          {steps.map((s, i) => (
            <div key={s.n} style={{
              padding:'22px 18px', minHeight:196,
              borderRight: i < steps.length - 1 ? 'var(--border-default)' : 'none',
            }}>
              <div style={{
                fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:15, fontWeight:700, color:'var(--fg-3)', marginBottom:14,
              }}>[{s.n}]</div>
              <div style={{
                fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
                fontWeight:700, fontSize:19, letterSpacing:'var(--ls-tight)', marginBottom:8,
              }}>{s.label}</div>
              <p style={{margin:0, fontSize:13, lineHeight:1.5, color:'var(--fg-2)'}}>{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

window.NextCase = function NextCase() {
  return (
    <section style={{padding:'52px 48px', background:'var(--paper-2)', borderBottom:'var(--border-default)'}}>
      <div style={{maxWidth:1100, margin:'0 auto', display:'flex', justifyContent:'space-between', alignItems:'center', gap:32, flexWrap:'wrap'}}>
        <div>
          <div style={{
            fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:700, color:'var(--fg-3)',
          }}>// up next, if you'd like</div>
          <h3 style={{
            margin:'10px 0 0', fontFamily:'var(--font-display)',
            fontVariationSettings:"'wdth' var(--wdth-display)", fontWeight:700,
            fontSize:'clamp(30px, 3.8vw, 48px)', lineHeight:1.04, letterSpacing:'-0.03em',
          }}>Notes app, again →</h3>
        </div>
        <Button as="a" href="#next">Read next ▸</Button>
      </div>
    </section>
  );
};
