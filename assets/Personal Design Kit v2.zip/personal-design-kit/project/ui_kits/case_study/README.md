# Case Study UI Kit

Long-form case study template — the storytelling surface for individual projects.

## Files

| File | Exports | Purpose |
|---|---|---|
| `header.jsx` | `CaseHeader`, `CaseHero`, `MetricRow` | Sticky top bar, hero with role/team/duration facts, inverse metric strip. |
| `sections.jsx` | `Prose`, `QuoteBlock`, `BeforeAfter`, `ProcessTimeline`, `NextCase` | Mid-page content blocks. |

Reuses `primitives.jsx` and `chrome.jsx` from the portfolio kit (single source of truth for `Button`, `SectionMarker`, `Footer`, etc.).

## Composition (in `index.html`)

```
<CaseHeader/>     ← thin sticky bar with "back to studio" link
<CaseHero/>       ← tag, year, title, kicker paragraph, role/team/duration facts
<MetricRow/>      ← inverse strip with up to 4 hero numbers
<Prose/>          ← long-form sections, narrow column
<QuoteBlock/>     ← pull quote on blue pale
<BeforeAfter/>    ← 2-up frame with fake UI mocks
<ProcessTimeline/>← 5-step horizontal process strip
<Prose/>          ← reflection / "what I'd do differently"
<NextCase/>       ← next-up promo on paper 2
<Footer/>
```

## Notes

- `BeforeAfter` ships with two inline fake UI mocks (`FakeUI`) — replace with real screenshots when you have them. The "before" frame is labelled in rust, the "after" in deep green; these are the only functional-colour labels in the template.
- All sections are full-bleed; column constraint happens inside via `maxWidth: 1100` (or `68ch` for prose).
- Background rhythm: paper → ink → paper → blue pale → paper 2 → paper → paper 2. One inverse band, one pale-accent band, everything else neutral.
