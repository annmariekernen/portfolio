window.CaseHeader = function CaseHeader() {
  return (
    <header style={{
      borderBottom:'var(--border-heavy)', background:'var(--paper)',
      padding:'16px 40px', display:'flex', alignItems:'center', justifyContent:'space-between',
      position:'sticky', top:0, zIndex:10,
    }}>
      <a href="../portfolio/index.html" style={{
        textDecoration:'none', color:'var(--fg-1)',
        fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
        fontWeight:700, fontSize:18, letterSpacing:'-0.01em',
        display:'flex', alignItems:'center', gap:10,
      }}>◂ STUDIO<span style={{color:'var(--blue-deep)'}}>//</span></a>
      <div style={{
        fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:500, color:'var(--fg-3)',
        display:'flex', alignItems:'center', gap:12,
      }}>
        <span style={{width:7, height:7, background:'var(--green-deep)', display:'inline-block'}}/>
        ▸ reading · case 03 / 12
      </div>
    </header>
  );
};

window.CaseHero = function CaseHero({ tag, title, sub, year, role, team, duration }) {
  return (
    <section style={{
      padding:'72px 48px 56px', borderBottom:'var(--border-default)', background:'var(--paper)',
    }}>
      <div style={{maxWidth:1100, margin:'0 auto'}}>
        <div style={{display:'flex', gap:8, marginBottom:26}}>
          <Tag variant="blue">{tag}</Tag>
          <Tag>▸ {year}</Tag>
        </div>
        <h1 style={{
          margin:0, fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
          fontWeight:700, fontSize:'clamp(44px, 5.8vw, 72px)', lineHeight:1.02,
          letterSpacing:'-0.03em', maxWidth:'18ch',
        }}>{title}</h1>
        <p style={{marginTop:26, fontSize:20, lineHeight:1.45, color:'var(--fg-2)', maxWidth:'56ch'}}>{sub}</p>
        <div style={{
          marginTop:44, display:'grid', gridTemplateColumns:'repeat(3, 1fr)',
          border:'var(--border-default)', background:'var(--bone)',
        }}>
          <CaseFact label="Role" value={role}/>
          <CaseFact label="Team" value={team}/>
          <CaseFact label="Duration" value={duration} last/>
        </div>
      </div>
    </section>
  );
};

function CaseFact({ label, value, last }) {
  return (
    <div style={{padding:'18px 22px', borderRight: last ? 'none' : 'var(--border-default)'}}>
      <div style={{
        fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:700, color:'var(--fg-3)',
      }}>// {label}</div>
      <div style={{fontSize:17, fontWeight:600, marginTop:6, lineHeight:1.25}}>{value}</div>
    </div>
  );
}

window.MetricRow = function MetricRow({ items }) {
  return (
    <section style={{padding:'44px 48px', borderBottom:'var(--border-default)', background:'var(--ink)', color:'var(--fg-inverse)'}}>
      <div style={{
        maxWidth:1100, margin:'0 auto', display:'grid',
        gridTemplateColumns:`repeat(${items.length}, 1fr)`,
      }}>
        {items.map((m, i) => (
          <div key={i} style={{
            padding:'6px 24px',
            borderRight: i < items.length - 1 ? '1px solid var(--ink-soft)' : 'none',
          }}>
            <div style={{
              fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:700, color:'var(--mist)',
            }}>// {m.label}</div>
            <div style={{
              marginTop:10, fontFamily:'var(--font-display)',
              fontVariationSettings:"'wdth' var(--wdth-display)", fontWeight:700,
              fontSize:44, lineHeight:1, letterSpacing:'-0.03em', color: m.color || 'var(--paper)',
            }}>{m.value}</div>
            <div style={{marginTop:8, fontSize:12, color:'var(--ink-faint)'}}>{m.note}</div>
          </div>
        ))}
      </div>
    </section>
  );
};
