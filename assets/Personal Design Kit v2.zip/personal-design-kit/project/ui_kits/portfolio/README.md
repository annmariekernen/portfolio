# Portfolio UI Kit

A personal portfolio homepage in the v2 vocabulary. Demonstrates the full visual system in a real layout.

## Files

| File | Exports | Purpose |
|---|---|---|
| `primitives.jsx` | `Button`, `Tag`, `Card`, `MetaLine`, `SectionMarker`, `Band` | Local mirrors of the library primitives, plus the section shell. |
| `chrome.jsx` | `TopNav`, `Footer` | Sticky nav with a heavy rule; inverse footer with link columns. |
| `hero.jsx` | `Hero`, `MarqueeStrip` | Above-the-fold hero, plus a scrolling skill ticker. |
| `workgrid.jsx` | `WorkGrid` | 2-column case-study grid; the ghost outline appears on hover. |
| `sections.jsx` | `NowPlaying`, `PrincipleStrip`, `ContactCTA` | Mid-page content blocks. |

These are page fragments, not library components — copy and edit them. For the maintained versions of the primitives, import from the compiled bundle instead (`components/`).

## Composition (in `index.html`)

```
<TopNav/>
<Hero/>            ← name, tagline, primary CTA
<MarqueeStrip/>    ← scrolling skill ticker
<WorkGrid/>        ← 4 selected projects
<PrincipleStrip/>  ← 4 operating principles, on paper 2
<NowPlaying/>      ← what's in flight, on the one inverse band
<ContactCTA/>      ← full-bleed contact section
<Footer/>          ← inverse footer with link cols
```

## Interaction

- Clicking a work card opens a placeholder case-study modal.
- Top nav switches the active tab visually (no routing).
- Hover states darken by one step; nothing translates. Work cards gain the ghost outline.

## Notes

- All assets load from `../../assets/`.
- Tokens come from `../../styles.css` — never link `colors_and_type.css` (the v1 archive).
- Components export to `window.*` so multiple Babel script tags can share scope.
- `MarqueeStrip` is the one element carried over from v1 on instinct rather than argument. Delete it freely.
