window.Hero = function Hero() {
  return (
    <section style={{
      borderBottom:'var(--border-default)', padding:'88px 48px 72px', background:'var(--paper)',
    }}>
      <div style={{maxWidth:1200, margin:'0 auto'}}>
        <div style={{display:'flex', alignItems:'center', gap:12, marginBottom:28}}>
          <span style={{width:9, height:9, background:'var(--green-deep)', display:'inline-block'}}/>
          <span style={{
            fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:15, fontWeight:600, color:'var(--fg-2)',
          }}>// hi! taking new work for q3 · sf / remote</span>
        </div>

        <h1 style={{
          margin:0, fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
          fontWeight:700, fontSize:'clamp(44px, 5.6vw, 72px)', lineHeight:1.02,
          letterSpacing:'-0.03em', maxWidth:'17ch',
        }}>Complex systems, warmly shipped.</h1>

        <p style={{marginTop:32, maxWidth:'52ch', fontSize:19, lineHeight:1.5, color:'var(--fg-2)'}}>
          hi, i'm a ux designer for complex products — admin tools, design tooling, anything with a sidebar and a real workflow. pull up a chair, the kettle's on. i'd love to show you what i've been building.
        </p>

        <div style={{display:'flex', gap:14, marginTop:36, flexWrap:'wrap'}}>
          <Button as="a" href="#work">Come see the work ▸</Button>
          <Button as="a" href="#contact" variant="ghost">Say hello ▸</Button>
        </div>
      </div>
    </section>
  );
};

window.MarqueeStrip = function MarqueeStrip() {
  const items = ['Design systems','Prototypes','Research ops','Zero→one','▸','Enterprise tools','Motion','Workflow design','▸','API design','Design eng','▸'];
  return (
    <div style={{
      background:'var(--paper-2)', color:'var(--fg-2)',
      borderBottom:'var(--border-default)', padding:'13px 0',
      overflow:'hidden', whiteSpace:'nowrap',
      fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontWeight:600, fontSize:15, letterSpacing:'0.12em',
    }}>
      <div style={{display:'inline-block', animation:'scroll 60s linear infinite'}}>
        {[...items, ...items, ...items].map((it, i) => (
          <span key={i} style={{padding:'0 22px'}}>{it}</span>
        ))}
      </div>
      <style>{`@keyframes scroll { 0% { transform: translateX(0) } 100% { transform: translateX(-33.333%) } }`}</style>
    </div>
  );
};
