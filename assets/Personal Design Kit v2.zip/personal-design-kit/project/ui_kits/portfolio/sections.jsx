window.NowPlaying = function NowPlaying() {
  return (
    <Band ink style={{borderBottom:'none'}}>
      <div style={{display:'grid', gridTemplateColumns:'1fr 2fr', gap:48, alignItems:'start'}}>
        <div>
          <div style={{
            fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
            fontWeight:700, fontSize:34, lineHeight:1.05, letterSpacing:'var(--ls-tight)',
          }}>Now playing</div>
          <div style={{
            marginTop:10, fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:500, color:'var(--ink-faint)',
          }}>// last updated 2026.08.27</div>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:16}}>
          <NowRow status="Shipping" color="var(--green)" label="Notes app, v0.3" desc="finally fixing the graph layer i broke in v0.2 — close!"/>
          <NowRow status="Reading" color="var(--mist)" label="every public design system" desc="yes, all of them. happy to swap notes over coffee."/>
          <NowRow status="Writing" color="var(--blue)" label="design tokens that don't lie" desc="a friendly conf talk. 22 min. receipts inside."/>
          <NowRow status="Open" color="var(--green)" label="freelance, q3" desc="2 slots open. drop me a line, i'd love to hear about it."/>
        </div>
      </div>
    </Band>
  );
};

function NowRow({ status, color, label, desc }) {
  return (
    <div style={{
      display:'grid', gridTemplateColumns:'116px 1fr', gap:24, alignItems:'baseline',
      paddingBottom:14, borderBottom:'1px solid var(--ink-soft)',
    }}>
      <div style={{display:'flex', alignItems:'center', gap:8}}>
        <span style={{width:7, height:7, background:color, display:'inline-block'}}/>
        <span style={{
          fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:700, color,
        }}>{status}</span>
      </div>
      <div>
        <div style={{fontSize:19, fontWeight:600, lineHeight:1.25}}>{label}</div>
        <div style={{fontSize:14, color:'var(--mist)', marginTop:5}}>{desc}</div>
      </div>
    </div>
  );
}

window.PrincipleStrip = function PrincipleStrip() {
  const principles = [
    { n:'01', title:'Specifics > vibes', body:'numbers, screenshots, the exact words. happy to show the receipts.' },
    { n:'02', title:'Constraint as gift', body:'every "we can\'t" is a little design brief, generously wrapped.' },
    { n:'03', title:'Boring on purpose', body:"novel UI is a tax. let's spend it where it earns its keep." },
    { n:'04', title:'Ship to learn', body:'a v0.1 in prod beats a v3 in figma. always.' },
  ];
  return (
    <Band alt>
      <SectionMarker num="[02]">Operating principles</SectionMarker>
      <div style={{
        display:'grid', gridTemplateColumns:'repeat(4, 1fr)',
        border:'var(--border-default)', background:'var(--bone)',
      }}>
        {principles.map((p, i) => (
          <div key={p.n} style={{
            padding:'24px 22px', minHeight:206,
            borderRight: i < principles.length - 1 ? 'var(--border-default)' : 'none',
          }}>
            <div style={{
              fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:15, fontWeight:700, color:'var(--fg-3)',
            }}>[{p.n}]</div>
            <h4 style={{
              margin:'14px 0 10px', fontFamily:'var(--font-display)',
              fontVariationSettings:"'wdth' var(--wdth-display)", fontWeight:700,
              fontSize:21, lineHeight:1.12, letterSpacing:'var(--ls-tight)',
            }}>{p.title}</h4>
            <p style={{margin:0, fontSize:14, lineHeight:1.5, color:'var(--fg-2)'}}>{p.body}</p>
          </div>
        ))}
      </div>
    </Band>
  );
};

window.ContactCTA = function ContactCTA() {
  return (
    <Band>
      <div style={{maxWidth:'46ch'}}>
        <div style={{
          fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:15, fontWeight:700,
          color:'var(--fg-3)', marginBottom:20,
        }}>// let's build something lovely together</div>
        <h2 style={{
          margin:0, fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
          fontWeight:700, fontSize:'clamp(36px, 4.4vw, 56px)', lineHeight:1.04, letterSpacing:'-0.03em',
        }}>Got a complex problem? I'd love to hear it.</h2>
        <p style={{marginTop:22, fontSize:18, lineHeight:1.5, color:'var(--fg-2)'}}>
          send it over — the messier the better. i'll tell you honestly whether i'm the right person for it.
        </p>
        <div style={{marginTop:32, display:'flex', gap:14, flexWrap:'wrap'}}>
          <Button as="a" href="#hello">Say hello ▸</Button>
          <Button as="a" href="#chat" variant="ghost">Book a 15-min chat ▸</Button>
        </div>
      </div>
    </Band>
  );
};
