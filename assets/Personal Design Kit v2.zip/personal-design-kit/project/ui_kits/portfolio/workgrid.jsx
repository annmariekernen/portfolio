window.WorkGrid = function WorkGrid({ onOpen }) {
  const items = [
    { id:'checkout', idx:'01', year:'2025', tag:'Case study', title:'Rebuilt the checkout', sub:'cut signup 47s → 12s, 38% lift. come see how!', fill:'bone', accent:'var(--blue-deep)' },
    { id:'notes',    idx:'02', year:'2026', tag:'In progress', title:'Notes app, again', sub:'rewiring the graph layer. v0.3, getting close!', fill:'quiet', accent:'var(--green-deep)' },
    { id:'admin',    idx:'03', year:'2024', tag:'Case study', title:'Admin, reimagined', sub:'12 dashboards → 1 lovely command palette.', fill:'bone', accent:'var(--blue-deep)' },
    { id:'tokens',   idx:'04', year:'2024', tag:'Talk', title:"Design tokens that don't lie", sub:'a friendly conf talk. 22 min, receipts inside.', fill:'quiet', accent:'var(--green-deep)' },
  ];
  return (
    <Band>
      <SectionMarker num="[01]">Selected work</SectionMarker>
      <div style={{display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:32}}>
        {items.map(it => (
          <a key={it.id} href={'#' + it.id} onClick={(e)=>{e.preventDefault();onOpen&&onOpen(it.id)}} style={{textDecoration:'none', color:'inherit'}}>
            <WorkCard {...it}/>
          </a>
        ))}
      </div>
    </Band>
  );
};

function WorkCard({ idx, year, tag, title, sub, fill, accent }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{
        background: fill === 'quiet' ? 'var(--paper-2)' : 'var(--bone)',
        border:'var(--border-default)',
        boxShadow: hover ? 'var(--ghost)' : 'none',
        transition:'box-shadow var(--dur-fast) var(--ease-snap)',
        display:'grid', gridTemplateColumns:'1fr 92px', minHeight:212, cursor:'pointer',
      }}>
      <div style={{padding:'24px 26px', display:'flex', flexDirection:'column'}}>
        <MetaLine>▸ {year} · {tag}</MetaLine>
        <h3 style={{
          margin:'10px 0 12px', fontFamily:'var(--font-display)',
          fontVariationSettings:"'wdth' var(--wdth-display)", fontWeight:700,
          fontSize:28, lineHeight:1.08, letterSpacing:'var(--ls-tight)',
        }}>{title}</h3>
        <p style={{margin:0, fontSize:15, lineHeight:1.5, color:'var(--fg-2)'}}>{sub}</p>
        <div style={{
          marginTop:'auto', paddingTop:18,
          fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontWeight:600, fontSize:16, color: accent,
        }}>Read it {hover ? '▸▸' : '▸'}</div>
      </div>
      <div style={{
        borderLeft:'var(--border-default)',
        background: fill === 'quiet' ? 'var(--bone)' : 'var(--paper-2)',
        display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'20px 0',
      }}>
        <span style={{
          fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
          fontWeight:700, fontSize:34, letterSpacing:'-0.02em', color:'var(--ink-faint)',
        }}>{idx}</span>
      </div>
    </div>
  );
}
