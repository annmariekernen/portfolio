window.TopNav = function TopNav({ active='work', onNav }) {
  const items = [
    { id:'work',  label:'Work' },
    { id:'notes', label:'Field notes' },
    { id:'now',   label:'Now' },
    { id:'about', label:'About' },
  ];
  return (
    <nav style={{
      borderBottom:'var(--border-heavy)', background:'var(--paper)',
      position:'sticky', top:0, zIndex:10,
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'0 40px', height:66,
    }}>
      <a href="#home" onClick={(e)=>{e.preventDefault();onNav&&onNav('home')}} style={{
        textDecoration:'none', color:'var(--fg-1)',
        fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
        fontWeight:700, fontSize:22, letterSpacing:'-0.01em',
      }}>STUDIO<span style={{color:'var(--blue-deep)'}}>//</span></a>

      <div style={{display:'flex', alignItems:'center', gap:28}}>
        {items.map(it => (
          <a key={it.id} href={'#' + it.id} onClick={(e)=>{e.preventDefault();onNav&&onNav(it.id)}} style={{
            fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:15, fontWeight:600, textDecoration:'none',
            color: active === it.id ? 'var(--fg-1)' : 'var(--fg-2)',
            borderBottom: active === it.id ? 'var(--border-default)' : '1.5px solid transparent',
            paddingBottom:3,
          }}>{it.label}</a>
        ))}
        <Button as="a" href="#contact">Hire me ▸</Button>
      </div>
    </nav>
  );
};

window.Footer = function Footer() {
  return (
    <footer style={{
      borderTop:'var(--border-heavy)', background:'var(--ink)', color:'var(--fg-inverse)',
      padding:'56px 48px 32px',
    }}>
      <div style={{maxWidth:1200, margin:'0 auto', display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr', gap:40}}>
        <div>
          <div style={{
            fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
            fontWeight:700, fontSize:30, letterSpacing:'-0.02em',
          }}>STUDIO<span style={{color:'var(--mist)'}}>//</span></div>
          <p style={{fontSize:15, lineHeight:1.55, marginTop:14, maxWidth:360, color:'var(--mist)'}}>
            ux designer. systems person. shipping things since the dial-up era.
          </p>
        </div>
        <FootCol title="Work" items={['Case studies','Now','Archive']}/>
        <FootCol title="Writing" items={['Field notes','Talks','Receipts']}/>
        <FootCol title="Elsewhere" items={['Email ↗','GitHub ↗','read.cv ↗']}/>
        <div style={{
          gridColumn:'1 / -1', borderTop:'1px solid var(--ink-soft)', paddingTop:22, marginTop:12,
          display:'flex', justifyContent:'space-between', flexWrap:'wrap', gap:12,
          fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:14, fontWeight:500, color:'var(--ink-faint)',
        }}>
          <span>// © 2026 · made with care</span>
          <span>v0.2 · last deploy 2h ago, thanks for visiting</span>
        </div>
      </div>
    </footer>
  );
};

function FootCol({ title, items }) {
  return (
    <div>
      <div style={{
        fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontWeight:700, fontSize:14,
        color:'var(--mist)', marginBottom:14,
      }}>// {title}</div>
      <ul style={{listStyle:'none', padding:0, margin:0, display:'flex', flexDirection:'column', gap:9}}>
        {items.map(i => (
          <li key={i} style={{fontSize:14}}>
            <a href="#link" onClick={(e)=>e.preventDefault()} style={{color:'var(--paper)', textDecoration:'none'}}>{i}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
