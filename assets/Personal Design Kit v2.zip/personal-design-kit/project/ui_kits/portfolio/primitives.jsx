/* Local mirrors of the library primitives, styled entirely from tokens.
   Cherry-pick these into prototypes, or import the compiled components. */

const BTN_BASE = {
  fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontWeight:600, fontSize:'var(--fs-base)',
  padding:'11px 18px', border:'var(--border-default)', cursor:'pointer',
  display:'inline-block', textDecoration:'none',
  transition:'background var(--dur-fast) var(--ease-snap), border-color var(--dur-fast) var(--ease-snap)',
};

window.Button = function Button({ children, variant='primary', onClick, as='button', href, disabled=false, onInk=false }) {
  const rest = {
    primary:   { background:'var(--action)', borderColor:'var(--action)', color:'var(--action-fg)' },
    secondary: { background:'var(--green-deep)', borderColor:'var(--green-deep)', color:'var(--bone)' },
    ghost:     { background:'transparent', borderColor: onInk ? 'var(--mist)' : 'var(--ink)', color: onInk ? 'var(--paper)' : 'var(--fg-1)' },
    ink:       { background:'var(--ink)', borderColor:'var(--ink)', color:'var(--paper)' },
  };
  const over = {
    primary:   { background:'var(--action-hover)', borderColor:'var(--action-hover)' },
    secondary: { background:'var(--green-deeper)', borderColor:'var(--green-deeper)' },
    ghost:     onInk ? { background:'var(--ink-soft)', borderColor:'var(--paper)' } : { background:'var(--mist-pale)' },
    ink:       { background:'var(--ink-soft)', borderColor:'var(--ink-soft)' },
  };
  const [hover, setHover] = React.useState(false);
  const style = {
    ...BTN_BASE, ...(rest[variant] || rest.primary),
    ...(hover && !disabled ? over[variant] : null),
    ...(disabled ? { background:'var(--mist-pale)', borderColor:'var(--mist)', color:'var(--ink-faint)', cursor:'not-allowed' } : null),
  };
  const p = disabled ? { style } : { style, onMouseEnter:()=>setHover(true), onMouseLeave:()=>setHover(false), onClick };
  return as === 'a' ? <a href={href} {...p}>{children}</a> : <button type="button" disabled={disabled} {...p}>{children}</button>;
};

const TAG_FILLS = {
  default:   { background:'transparent', color:'var(--fg-1)', borderColor:'var(--ink)' },
  blue:      { background:'var(--blue-deep)', color:'var(--bone)', borderColor:'var(--blue-deep)' },
  green:     { background:'var(--green-deep)', color:'var(--bone)', borderColor:'var(--green-deep)' },
  bluePale:  { background:'var(--blue-pale)', color:'var(--fg-1)', borderColor:'var(--ink)' },
  greenPale: { background:'var(--green-pale)', color:'var(--fg-1)', borderColor:'var(--ink)' },
  mist:      { background:'var(--mist-pale)', color:'var(--fg-1)', borderColor:'var(--ink)' },
  rust:      { background:'var(--rust)', color:'var(--bone)', borderColor:'var(--rust)' },
  ink:       { background:'var(--ink)', color:'var(--paper)', borderColor:'var(--ink)' },
};

window.Tag = function Tag({ children, variant='default', dot=false }) {
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:'var(--space-3)',
      fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:'var(--fs-sm)', fontWeight:600,
      padding:'4px 10px', border:'var(--border-default)',
      ...(TAG_FILLS[variant] || TAG_FILLS.default),
    }}>
      {dot && <span style={{width:7, height:7, background:'currentColor', display:'inline-block'}}/>}
      {children}
    </span>
  );
};

const CARD_SURFACES = { bone:'var(--bone)', paper:'var(--paper)', quiet:'var(--paper-2)', bluePale:'var(--blue-pale)', greenPale:'var(--green-pale)', ink:'var(--ink)' };
const CARD_GHOSTS = { paper:'var(--ghost)', alt:'var(--ghost-alt)', bright:'var(--ghost-bright)', none:'none' };

window.Card = function Card({ children, fill='bone', ghost='paper', hero=false, style={} }) {
  return (
    <div style={{
      background: CARD_SURFACES[fill] || CARD_SURFACES.bone,
      border: hero ? 'var(--border-heavy)' : 'var(--border-default)',
      boxShadow: CARD_GHOSTS[ghost] || CARD_GHOSTS.paper,
      padding: hero ? 'var(--space-7)' : 'var(--space-6)',
      color: fill === 'ink' ? 'var(--fg-inverse)' : 'var(--fg-1)',
      ...style,
    }}>{children}</div>
  );
};

window.MetaLine = function MetaLine({ children, tone='muted' }) {
  const tones = { muted:'var(--fg-3)', ink:'var(--fg-1)', inverse:'var(--mist)' };
  return <div style={{
    fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontSize:'var(--fs-sm)', fontWeight:500, color: tones[tone] || tones.muted,
  }}>{children}</div>;
};

window.SectionMarker = function SectionMarker({ num, children, rule='default' }) {
  return (
    <div style={{
      display:'flex', alignItems:'baseline', gap:'var(--space-5)', padding:'0 0 14px 0',
      borderBottom: rule === 'heavy' ? 'var(--border-heavy)' : 'var(--border-default)',
      marginBottom:'var(--space-7)', flexWrap:'wrap',
    }}>
      {num && <span style={{
        fontFamily:'var(--font-body)', fontVariationSettings:"'wdth' var(--wdth-body)", fontVariantCaps:'var(--caps-variant)', fontFeatureSettings:'var(--caps-features)', letterSpacing:'var(--ls-caps)', textTransform:'none', fontWeight:700, fontSize:'var(--fs-base)', color:'var(--fg-3)', flexShrink:0,
      }}>{num}</span>}
      <h2 style={{
        margin:0, fontFamily:'var(--font-display)', fontVariationSettings:"'wdth' var(--wdth-display)",
        fontWeight:700, fontSize:'var(--fs-2xl)', lineHeight:'var(--lh-tight)', letterSpacing:'var(--ls-tight)',
      }}>{children}</h2>
    </div>
  );
};

/* Shared section shell: max width, generous vertical rhythm, hairline base. */
window.Band = function Band({ children, alt=false, ink=false, style={} }) {
  return (
    <section style={{
      padding:'72px 48px', borderBottom:'var(--border-default)',
      background: ink ? 'var(--ink)' : alt ? 'var(--paper-2)' : 'var(--paper)',
      color: ink ? 'var(--fg-inverse)' : 'var(--fg-1)',
      ...style,
    }}>
      <div style={{maxWidth:1200, margin:'0 auto'}}>{children}</div>
    </section>
  );
};
