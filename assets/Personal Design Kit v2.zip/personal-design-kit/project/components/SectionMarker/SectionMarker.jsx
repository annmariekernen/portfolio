export function SectionMarker({ num, children, rule = 'default' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', gap: 'var(--space-5)',
      padding: '0 0 14px 0',
      borderBottom: rule === 'heavy' ? 'var(--border-heavy)' : 'var(--border-default)',
      marginBottom: 'var(--space-7)', flexWrap: 'wrap',
    }}>
      {num && <span style={{
        fontFamily: 'var(--font-body)', fontVariationSettings: "'wdth' var(--wdth-body)",
        fontWeight: 700, fontSize: 'var(--fs-base)',
        fontVariantCaps: 'var(--caps-variant)', fontFeatureSettings: 'var(--caps-features)',
        letterSpacing: 'var(--ls-caps)', color: 'var(--fg-3)', flexShrink: 0,
      }}>{num}</span>}
      <h2 style={{
        margin: 0, fontFamily: 'var(--font-display)',
        fontVariationSettings: "'wdth' var(--wdth-display)", fontWeight: 700,
        fontSize: 'var(--fs-2xl)', lineHeight: 'var(--lh-tight)', letterSpacing: 'var(--ls-tight)',
      }}>{children}</h2>
    </div>
  );
}
