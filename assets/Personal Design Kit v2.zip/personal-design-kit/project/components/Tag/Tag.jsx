const FILLS = {
  default:    { background: 'transparent',       color: 'var(--fg-1)',  borderColor: 'var(--ink)' },
  blue:       { background: 'var(--blue-deep)',  color: 'var(--bone)',  borderColor: 'var(--blue-deep)' },
  green:      { background: 'var(--green-deep)', color: 'var(--bone)',  borderColor: 'var(--green-deep)' },
  bluePale:   { background: 'var(--blue-pale)',  color: 'var(--fg-1)',  borderColor: 'var(--ink)' },
  greenPale:  { background: 'var(--green-pale)', color: 'var(--fg-1)',  borderColor: 'var(--ink)' },
  mist:       { background: 'var(--mist-pale)',  color: 'var(--fg-1)',  borderColor: 'var(--ink)' },
  rust:       { background: 'var(--rust)',       color: 'var(--bone)',  borderColor: 'var(--rust)' },
  ink:        { background: 'var(--ink)',        color: 'var(--paper)', borderColor: 'var(--ink)' },
};

export function Tag({ children, variant = 'default', dot = false }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 'var(--space-3)',
      fontFamily: 'var(--font-body)', fontVariationSettings: "'wdth' var(--wdth-body)",
      fontSize: 'var(--fs-sm)', fontWeight: 600,
      fontVariantCaps: 'var(--caps-variant)', fontFeatureSettings: 'var(--caps-features)',
      letterSpacing: 'var(--ls-caps)', textTransform: 'none',
      padding: '4px 10px', border: 'var(--border-default)',
      ...(FILLS[variant] || FILLS.default),
    }}>
      {dot && <span style={{ width: 7, height: 7, background: 'currentColor', display: 'inline-block' }}/>}
      {children}
    </span>
  );
}
